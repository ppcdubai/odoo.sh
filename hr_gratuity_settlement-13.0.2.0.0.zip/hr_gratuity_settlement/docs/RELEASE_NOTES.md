## Module hr_gratuity

#### 10.10.2018
#### Version 13.0.1.0.0
##### ADD
- Initial Commit

#### 25.10.2020
#### Version 13.0.2.0.0
#### UPDT
- New Updations
- Provition for Probation
- Gratuvity Configuration
- Rules
- Calculation
